#!/usr/bin/bash
wd=$(dirname "$0")

open "$wd/build/robotone.pdf"