#!/usr/bin/bash
wd=$(dirname "$0")
xelatex=$(which xelatex)

"$wd/dist/build/robotone/robotone" 